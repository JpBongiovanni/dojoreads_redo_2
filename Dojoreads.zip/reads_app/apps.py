from django.apps import AppConfig


class ReadsAppConfig(AppConfig):
    name = 'reads_app'
